# -*- coding: utf-8 -*-
# pyRevit button script: Менеджер листов (v20 — фикс отступов, layout на Resize, багфикс 'Вниз')

import clr
import re

# --- AddReferences ДО импортов .NET ---
clr.AddReference('System')
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
clr.AddReference('RevitAPI')
clr.AddReference('RevitServices')
clr.AddReference('RevitAPIUI')

from System import Array, String
from System.Windows.Forms import (Form, ComboBox, Label, Button,
                                  ListView, ColumnHeader, AnchorStyles,
                                  View, ListViewItem, BorderStyle, FormStartPosition,
                                  ComboBoxStyle, MessageBox, MessageBoxButtons, MessageBoxIcon,
                                  NumericUpDown)
from System.Drawing import Size, Point

from Autodesk.Revit.DB import (FilteredElementCollector, ViewSheet, BuiltInParameter,
                               Transaction, TransactionGroup, IFailuresPreprocessor,
                               FailureProcessingResult, ElementId)

# --- Значения по умолчанию ---
DEFAULT_GROUP_PARAM = u"ADSK_Штамп Раздел проекта"
DEFAULT_NUM_PARAM   = u"DVLK_Штамп_Номер листа"

# --- Доступ к документу ---
uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document

# --- Helpers ---
def get_param_str(elem, name):
    p = elem.LookupParameter(name)
    if p:
        try:
            return (p.AsString() or u"").strip()
        except:
            pass
    return u""


def set_param_str(elem, name, value):
    p = elem.LookupParameter(name)
    if p and not p.IsReadOnly:
        p.Set(value)
        return True
    return False


def get_sheet_number(sheet):
    p = sheet.get_Parameter(BuiltInParameter.SHEET_NUMBER)
    return ((p.AsString() if p else u"") or u"").strip()


def set_sheet_number(sheet, value):
    p = sheet.get_Parameter(BuiltInParameter.SHEET_NUMBER)
    if p and not p.IsReadOnly:
        p.Set(value)
        return True
    return False


def is_placeholder(sheet):
    try:
        return sheet.IsPlaceholder
    except:
        return False


def get_sheets(document):
    return [s for s in FilteredElementCollector(document).OfClass(ViewSheet).ToElements() if not is_placeholder(s)]


_num_re = re.compile(r"(\d+)")
def natural_key(s):
    if s is None:
        s = u""
    parts = _num_re.split(s)
    key = []
    for i, part in enumerate(parts):
        if i % 2 == 0:
            key.append(part)
        else:
            try:
                key.append(int(part))
            except:
                key.append(part)
    return tuple(key)


# --- Failures suppressor (минимальный) ---
class SuppressErrors(IFailuresPreprocessor):
    def PreprocessFailures(self, fa):
        return FailureProcessingResult.Continue

def with_suppress(t):
    fho = t.GetFailureHandlingOptions()
    fho = fho.SetFailuresPreprocessor(SuppressErrors())
    t.SetFailureHandlingOptions(fho)


# --- Модель строки ---
class SheetRow(object):
    __slots__ = ("sheet_id", "sheetnum", "name")
    def __init__(self, sheet):
        self.sheet_id = sheet.Id.IntegerValue
        self.sheetnum = get_sheet_number(sheet) or u""
        self.name = sheet.Name or u""


# --- Сбор имён параметров ---
def collect_string_param_names(sheets):
    names_all = set()
    names_writable = set()
    for s in sheets:
        try:
            for p in s.Parameters:
                d = p.Definition
                if d is None:
                    continue
                nm = (d.Name or u"").strip()
                if not nm:
                    continue
                try:
                    _ = p.AsString()
                    names_all.add(nm)
                    if not p.IsReadOnly:
                        names_writable.add(nm)
                except:
                    pass
        except:
            pass
    return sorted(names_all, key=natural_key), sorted(names_writable, key=natural_key)


# --- Форма ---
class SheetManagerForm(Form):
    def __init__(self):
        self.Text = u"Менеджер листов | Нумерация"
        self.MinimumSize = Size(880, 600)
        self.Size = Size(960, 640)
        self.StartPosition = FormStartPosition.CenterScreen

        # Контролы параметров
        self.lblSortParam = Label(); self.lblSortParam.Text = u"Параметр сортировки:"; self.lblSortParam.AutoSize = True; self.lblSortParam.Location = Point(12, 14)
        self.cmbSortParam = ComboBox(); self.cmbSortParam.DropDownStyle = ComboBoxStyle.DropDownList; self.cmbSortParam.Location = Point(160, 10); self.cmbSortParam.Width = 220; self.cmbSortParam.Anchor = AnchorStyles.Top | AnchorStyles.Left

        self.lblGroupVal  = Label(); self.lblGroupVal.Text = u"Значение:"; self.lblGroupVal.AutoSize = True; self.lblGroupVal.Location = Point(390, 14)
        self.cmbGroupVal  = ComboBox(); self.cmbGroupVal.DropDownStyle = ComboBoxStyle.DropDownList; self.cmbGroupVal.Location = Point(460, 10); self.cmbGroupVal.Width = 200; self.cmbGroupVal.Anchor = AnchorStyles.Top | AnchorStyles.Left

        # ПОД 'Значение'
        self.lblStart  = Label(); self.lblStart.Text = u"Начинать с:"; self.lblStart.AutoSize = True; self.lblStart.Location = Point(460, 40)
        self.numStart  = NumericUpDown(); self.numStart.Minimum = 1; self.numStart.Maximum = 9999; self.numStart.Value = 1; self.numStart.Width = 70; self.numStart.Location = Point(540, 38)

        self.lblNumParam  = Label(); self.lblNumParam.Text = u"Параметр нумерации:"; self.lblNumParam.AutoSize = True; self.lblNumParam.Location = Point(12, 44)
        self.cmbNumParam  = ComboBox(); self.cmbNumParam.DropDownStyle = ComboBoxStyle.DropDownList; self.cmbNumParam.Location = Point(160, 40); self.cmbNumParam.Width = 220; self.cmbNumParam.Anchor = AnchorStyles.Top | AnchorStyles.Left

        # Таблица
        self.lv = ListView(); self.lv.View = View.Details; self.lv.FullRowSelect = True; self.lv.MultiSelect = False; self.lv.BorderStyle = BorderStyle.FixedSingle
        self.lv.Location = Point(12, 100); self.lv.Size = Size(830, 490); self.lv.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right

        ch1 = ColumnHeader(); ch1.Text = u"Порядок"; ch1.Width = 70
        ch2 = ColumnHeader(); ch2.Text = u"Сист. номер"; ch2.Width = 180
        ch3 = ColumnHeader(); ch3.Text = u"Имя листа"; ch3.Width = 360
        ch4 = ColumnHeader(); ch4.Text = DEFAULT_NUM_PARAM; ch4.Width = 180
        self.col_num = ch4
        self.lv.Columns.AddRange(Array[ColumnHeader]([ch1, ch2, ch3, ch4]))

        # Кнопки — оставляем отступы справа/снизу динамически
        self.btnUp   = Button(); self.btnUp.Text = u"▲ Вверх"; self.btnUp.Size = Size(100, 34)
        self.btnDown = Button(); self.btnDown.Text = u"▼ Вниз";  self.btnDown.Size = Size(100, 34)
        self.btnNumerate = Button(); self.btnNumerate.Text = u"Нумеровать"; self.btnNumerate.Size = Size(120, 34)
        self.btnCancel   = Button(); self.btnCancel.Text = u"Закрыть";    self.btnCancel.Size = Size(100, 34)

        for b in [self.btnUp, self.btnDown]:
            b.Anchor = AnchorStyles.Top | AnchorStyles.Right
        for b in [self.btnNumerate, self.btnCancel]:
            b.Anchor = AnchorStyles.Bottom | AnchorStyles.Right

        for c in [self.lblSortParam, self.cmbSortParam, self.lblGroupVal, self.cmbGroupVal, self.lblStart, self.numStart,
                  self.lblNumParam, self.cmbNumParam, self.lv, self.btnUp, self.btnDown, self.btnNumerate, self.btnCancel]:
            self.Controls.Add(c)

        # Данные
        self.sheets = [SheetRow(s) for s in get_sheets(doc)]
        self.sheet_map = {r.sheet_id: doc.GetElement(ElementId(r.sheet_id)) for r in self.sheets}

        # Список доступных параметров
        names_all, names_writable = collect_string_param_names(self.sheet_map.values())
        if DEFAULT_GROUP_PARAM not in names_all:
            names_all.insert(0, DEFAULT_GROUP_PARAM)
        if DEFAULT_NUM_PARAM not in names_writable:
            names_writable.insert(0, DEFAULT_NUM_PARAM)

        for n in names_all:
            self.cmbSortParam.Items.Add(n)
        for n in names_writable:
            self.cmbNumParam.Items.Add(n)

        try:
            self.cmbSortParam.SelectedIndex = max(0, list(self.cmbSortParam.Items).IndexOf(DEFAULT_GROUP_PARAM))
        except:
            self.cmbSortParam.SelectedIndex = 0
        try:
            self.cmbNumParam.SelectedIndex = max(0, list(self.cmbNumParam.Items).IndexOf(DEFAULT_NUM_PARAM))
        except:
            self.cmbNumParam.SelectedIndex = 0

        # События
        self.cmbSortParam.SelectedIndexChanged += self.on_sort_param_changed
        self.cmbGroupVal.SelectedIndexChanged  += self.on_group_value_changed
        self.cmbNumParam.SelectedIndexChanged  += self.on_num_param_changed
        self.btnUp.Click += self.on_move_up
        self.btnDown.Click += self.on_move_down
        self.btnNumerate.Click += self.on_numerate
        self.btnCancel.Click += self.on_cancel
        self.Resize += self.on_resize  # динамический лейаут

        # Инициал
        self.order_ids = []
        self.current_rows = []
        self.rebuild_group_values()
        self.reload_rows(set_initial_order=True)
        self._layout_controls()  # первичное размещение

    def _layout_controls(self):
        right_margin = 20
        bottom_margin = 20
        gap = 12

        client_w = self.ClientSize.Width
        client_h = self.ClientSize.Height

        # Правая колонка кнопок
        x_right = client_w - right_margin - self.btnUp.Width
        self.btnUp.Location = Point(x_right, self.lv.Top)
        self.btnDown.Location = Point(x_right, self.lv.Top + self.btnUp.Height + gap)

        # Нижние кнопки
        y_bottom = client_h - bottom_margin - self.btnNumerate.Height
        self.btnNumerate.Location = Point(client_w - right_margin - self.btnNumerate.Width, y_bottom)
        self.btnCancel.Location   = Point(self.btnNumerate.Left - gap - self.btnCancel.Width, y_bottom)

        # Ширина списка — до правой колонны с небольшим отступом
        new_lv_width = (x_right - gap) - self.lv.Left
        if new_lv_width > 200:
            self.lv.Width = new_lv_width
        # Высота списка — до нижних кнопок с отступом
        new_lv_height = (y_bottom - gap) - self.lv.Top
        if new_lv_height > 150:
            self.lv.Height = new_lv_height

    def on_resize(self, sender, args):
        self._layout_controls()

    # --- Построение списков ---
    def rebuild_group_values(self):
        sort_param = self.cmbSortParam.SelectedItem if self.cmbSortParam.SelectedItem else DEFAULT_GROUP_PARAM
        values = set()
        for sid, sh in self.sheet_map.items():
            v = get_param_str(sh, sort_param)
            if v:
                values.add(v)
        values = sorted(list(values), key=natural_key)
        self.cmbGroupVal.Items.Clear()
        for v in values:
            self.cmbGroupVal.Items.Add(v)
        if self.cmbGroupVal.Items.Count > 0:
            self.cmbGroupVal.SelectedIndex = 0

    def _make_item(self, index, row, num_param):
        sh = self.sheet_map[row.sheet_id]
        numval = get_param_str(sh, num_param)
        arr = Array[String]([str(index), row.sheetnum, row.name, numval])
        it = ListViewItem(arr); it.Tag = row.sheet_id
        return it

    def reload_rows(self, set_initial_order=False):
        sort_param = self.cmbSortParam.SelectedItem if self.cmbSortParam.SelectedItem else DEFAULT_GROUP_PARAM
        group_val  = self.cmbGroupVal.SelectedItem if self.cmbGroupVal.SelectedItem else u""
        num_param  = self.cmbNumParam.SelectedItem if self.cmbNumParam.SelectedItem else DEFAULT_NUM_PARAM

        rows = []
        for r in self.sheets:
            sh = self.sheet_map[r.sheet_id]
            if (get_param_str(sh, sort_param) or u"") == (group_val or u""):
                rows.append(r)

        # Начальный порядок
        if set_initial_order or not self.order_ids:
            any_num = False
            for r in rows:
                if (get_param_str(self.sheet_map[r.sheet_id], num_param) or u"").strip():
                    any_num = True; break
            if any_num:
                def key_num(r):
                    nv = (get_param_str(self.sheet_map[r.sheet_id], num_param) or u"").strip()
                    try:
                        return (0, int(nv))
                    except:
                        return (1, natural_key(nv), natural_key(r.sheetnum))
                rows.sort(key=key_num)
            else:
                rows.sort(key=lambda r: natural_key(r.sheetnum))
            self.order_ids = [r.sheet_id for r in rows]
        else:
            id_to_row = {r.sheet_id: r for r in rows}
            rows = [id_to_row[i] for i in self.order_ids if i in id_to_row]

        self.current_rows = rows

        # Обновить таблицу
        self.col_num.Text = self.cmbNumParam.SelectedItem if self.cmbNumParam.SelectedItem else DEFAULT_NUM_PARAM
        self.lv.BeginUpdate()
        try:
            self.lv.Items.Clear()
            for i, r in enumerate(self.current_rows, 1):
                self.lv.Items.Add(self._make_item(i, r, self.col_num.Text))
            if self.lv.Items.Count > 0:
                self.lv.Items[0].Selected = True
        finally:
            self.lv.EndUpdate()

    # --- События UI ---
    def on_sort_param_changed(self, sender, args):
        self.rebuild_group_values()
        self.order_ids = []
        self.reload_rows(set_initial_order=True)
        self._layout_controls()

    def on_group_value_changed(self, sender, args):
        self.order_ids = []
        self.reload_rows(set_initial_order=True)
        self._layout_controls()

    def on_num_param_changed(self, sender, args):
        self.reload_rows(set_initial_order=False)

    def _selected_index(self):
        return int(self.lv.SelectedIndices[0]) if self.lv.SelectedIndices.Count > 0 else -1

    def on_move_up(self, sender, args):
        idx = self._selected_index()
        if idx <= 0: return
        self.current_rows[idx-1], self.current_rows[idx] = self.current_rows[idx], self.current_rows[idx-1]
        self.order_ids[idx-1], self.order_ids[idx] = self.order_ids[idx], self.order_ids[idx-1]
        self._rerender_keep_selection(idx-1)

    def on_move_down(self, sender, args):
        idx = self._selected_index()
        if idx < 0 or idx >= len(self.current_rows)-1: return
        self.current_rows[idx+1], self.current_rows[idx] = self.current_rows[idx], self.current_rows[idx+1]
        self.order_ids[idx+1], self.order_ids[idx] = self.order_ids[idx], self.order_ids[idx+1]
        self._rerender_keep_selection(idx+1)

    def _rerender_keep_selection(self, new_index):
        self.lv.BeginUpdate()
        try:
            self.lv.Items.Clear()
            for i, r in enumerate(self.current_rows, 1):
                self.lv.Items.Add(self._make_item(i, r, self.col_num.Text))
            if 0 <= new_index < self.lv.Items.Count:
                self.lv.Items[new_index].Selected = True
                self.lv.Items[new_index].Focused = True
                self.lv.EnsureVisible(new_index)
        finally:
            self.lv.EndUpdate()

    # --- Нумерация ---
    def on_numerate(self, sender, args):
        if not self.current_rows:
            return  # тихо

        sort_param = self.cmbSortParam.SelectedItem if self.cmbSortParam.SelectedItem else DEFAULT_GROUP_PARAM
        num_param  = self.cmbNumParam.SelectedItem if self.cmbNumParam.SelectedItem else DEFAULT_NUM_PARAM
        start_at   = int(self.numStart.Value)

        ids_in_order = list(self.order_ids)

        # План
        plan = []  # (sheet, dvlk, adsk, tmp_num, final_num)
        for idx, sid in enumerate(ids_in_order, 1):
            sh = self.sheet_map[sid]
            adsk = (get_param_str(sh, sort_param) or u"").strip()
            dvlk = unicode(start_at + idx - 1)
            tmp_num   = adsk + dvlk         # временный
            final_num = dvlk + u"_" + adsk # финальный
            plan.append((sh, dvlk, adsk, tmp_num, final_num))

        tg = TransactionGroup(doc, u"Нумерация листов"); tg.Start()

        t1 = Transaction(doc, u"Временные номера"); t1.Start(); with_suppress(t1)
        try:
            for (sh, dvlk, adsk, tmp_num, final_num) in plan:
                set_sheet_number(sh, tmp_num)
        except Exception as ex:
            t1.RollBack(); tg.RollBack()
            MessageBox.Show(u"Ошибка на шаге временных номеров: " + unicode(ex), u"Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error)
            return
        t1.Commit()

        t2 = Transaction(doc, u"Финальные номера"); t2.Start(); with_suppress(t2)
        try:
            for (sh, dvlk, adsk, tmp_num, final_num) in plan:
                set_sheet_number(sh, final_num)
                set_param_str(sh, num_param, dvlk)
        except Exception as ex:
            t2.RollBack(); tg.RollBack()
            MessageBox.Show(u"Ошибка на шаге финальных номеров: " + unicode(ex), u"Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error)
            return
        t2.Commit()

        tg.Assimilate()

        # Обновить интерфейс без окон
        self.sheets = [SheetRow(s) for s in get_sheets(doc)]
        self.sheet_map = {r.sheet_id: doc.GetElement(ElementId(r.sheet_id)) for r in self.sheets}
        self.order_ids = []
        self.reload_rows(set_initial_order=True)

    def on_cancel(self, sender, args):
        self.Close()


# --- Запуск ---
form = SheetManagerForm()
form.ShowDialog()
