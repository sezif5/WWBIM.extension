# -*- coding: utf-8 -*-
# PyRevit script: автоматическая проставка высотных отметок Spot Elevation
# Работает в активном виде (план, 3D, разрез и т.п.)
# Пользователь выбирает трубы, воздуховоды, кабельные лотки.
# Для вертикальных и наклонных труб ставятся отметки на обоих концах.
# Для горизонтальных труб — одна отметка на конце.
# Для воздуховодов и кабельных лотков — отметка по низу.
# Тип высотной отметки берется жестко: ADSK_Схема_Проектная_Отметка снизу_Вверх
# Выноска горизонтальная, длина ~10 мм на листе.
# Сторона (влево/вправо) выбирается по соседним МЭП-элементам на виде:
# выноска ставится туда, где рядом меньше соседних элементов (без анализа аннотаций).

from Autodesk.Revit.DB import (
    XYZ,
    FilteredElementCollector,
    SpotDimensionType,
    BuiltInParameter,
    Reference,
    FamilyInstance,
    BoundingBoxXYZ,
    BuiltInCategory,
    ElementId,
    Options,
    Solid,
    Face,
)
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.DB.Electrical import CableTray
from Autodesk.Revit.UI import Selection
from System.Collections.Generic import List
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc
active_view = doc.ActiveView

TOL = 1e-6
SPOT_TYPE_NAME = u"ADSK_Схема_Проектная_Отметка снизу_Вверх"
PAPER_LEADER_MM = 10.0  # длина выноски на листе, мм

# Категории, которые считаем МЭП-соседями (geometry only, без аннотаций)
MEP_NEIGHBOR_CAT_IDS = set([
    int(BuiltInCategory.OST_PipeCurves),
    int(BuiltInCategory.OST_DuctCurves),
    int(BuiltInCategory.OST_CableTray),
])


class PipeDuctCableTraySelectionFilter(Selection.ISelectionFilter):
    def AllowElement(self, element):
        try:
            if isinstance(element, Pipe):
                return True
            if isinstance(element, Duct):
                return True
            if isinstance(element, CableTray):
                return True
        except:
            pass
        return False

    def AllowReference(self, reference, point):
        return False


def get_selected_elements():
    sel_ids = list(uidoc.Selection.GetElementIds())
    elements = []
    selected_ids = set()  # Для отслеживания уже выбранных
    
    # Сначала добавляем уже выделенные элементы
    for eid in sel_ids:
        el = doc.GetElement(eid)
        if isinstance(el, Pipe) or isinstance(el, Duct) or isinstance(el, CableTray):
            elements.append(el)
            selected_ids.add(eid.IntegerValue)

    # Если ничего не выбрано - просим выбрать (множественный выбор)
    if not elements:
        try:
            refs = uidoc.Selection.PickObjects(
                Selection.ObjectType.Element,
                PipeDuctCableTraySelectionFilter(),
                u"Выберите элементы (трубы, воздуховоды, кабельные лотки). Enter/Esc для завершения"
            )
        except:
            return []
        for r in refs:
            el = doc.GetElement(r.ElementId)
            eid_int = r.ElementId.IntegerValue
            if eid_int in selected_ids:
                continue
            if isinstance(el, Pipe) or isinstance(el, Duct) or isinstance(el, CableTray):
                elements.append(el)
                selected_ids.add(eid_int)
    else:
        # Если уже есть выбранные - спрашиваем, хочет ли пользователь добавить ещё
        add_more = forms.alert(
            u"Выбрано элементов: {0}\n\nДобавить ещё элементов к выбору?".format(len(elements)),
            title=u"Высотные отметки",
            yes=True,
            no=True
        )
        if add_more:
            try:
                refs = uidoc.Selection.PickObjects(
                    Selection.ObjectType.Element,
                    PipeDuctCableTraySelectionFilter(),
                    u"Выберите дополнительные элементы. Enter/Esc для завершения"
                )
                for r in refs:
                    el = doc.GetElement(r.ElementId)
                    eid_int = r.ElementId.IntegerValue
                    if eid_int in selected_ids:
                        continue
                    if isinstance(el, Pipe) or isinstance(el, Duct) or isinstance(el, CableTray):
                        elements.append(el)
                        selected_ids.add(eid_int)
            except:
                pass  # Пользователь отменил - работаем с тем что есть
    
    return elements


def build_neighbor_points():
    """Собираем центры соседних МЭП-элементов на активном виде (для выбора стороны выноски)."""
    neighbors = []
    if active_view is None:
        return neighbors

    col = FilteredElementCollector(doc, active_view.Id).WhereElementIsNotElementType().ToElements()

    for el in col:
        cat = el.Category
        if not cat:
            continue
        if cat.Id.IntegerValue not in MEP_NEIGHBOR_CAT_IDS:
            continue
        try:
            bb = el.get_BoundingBox(active_view)
        except:
            bb = None
        if not isinstance(bb, BoundingBoxXYZ) or bb.Min is None or bb.Max is None:
            continue
        center = (bb.Min + bb.Max) * 0.5
        neighbors.append((el.Id, center))
    return neighbors


def get_spot_type_fixed():
    types = list(FilteredElementCollector(doc).OfClass(SpotDimensionType).ToElements())
    for stype in types:
        try:
            name_param = stype.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
            if name_param and name_param.AsString() == SPOT_TYPE_NAME:
                return stype
        except:
            continue

    forms.alert(
        u"Не найден тип высотной отметки с именем '{0}'.\nПроверь, что он загружен в проект и имя совпадает.".format(
            SPOT_TYPE_NAME),
        exitscript=True
    )
    return None


def ask_axis_or_bottom_for_pipes():
    options = [
        u"По оси трубы",
        u"По низу трубы (приблизительно)"
    ]

    chosen = forms.SelectFromList.show(
        options,
        title=u"Откуда брать отметку относительно трубы?",
        multiselect=False
    )

    if not chosen:
        return None

    if u"оси" in chosen:
        return "axis"
    return "bottom"


def get_pipe_points(pipe, mode):
    loc = pipe.Location
    if not loc:
        return []

    curve = getattr(loc, 'Curve', None)
    if not curve:
        return []

    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)

    c0 = XYZ(p0.X, p0.Y, p0.Z)
    c1 = XYZ(p1.X, p1.Y, p1.Z)

    if mode == 'bottom':
        # Получаем ВНЕШНИЙ диаметр трубы (наружный)
        radius = 0.0
        
        # Сначала пробуем внешний диаметр
        try:
            outer_diam_param = pipe.get_Parameter(BuiltInParameter.RBS_PIPE_OUTER_DIAMETER)
            if outer_diam_param and outer_diam_param.HasValue:
                radius = outer_diam_param.AsDouble() / 2.0
        except:
            pass
        
        # Если не получилось - пробуем обычный диаметр (менее точно)
        if radius <= 0:
            try:
                diam_param = pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
                if diam_param:
                    radius = diam_param.AsDouble() / 2.0
            except:
                pass
        
        # Последний вариант - свойство Diameter
        if radius <= 0:
            try:
                radius = pipe.Diameter / 2.0
            except:
                radius = 0.0
        
        if radius > 0.0:
            c0 = XYZ(c0.X, c0.Y, c0.Z - radius)
            c1 = XYZ(c1.X, c1.Y, c1.Z - radius)

    d = p1 - p0
    is_horizontal = abs(d.Z) < TOL
    
    # Длина трубы в футах
    pipe_length = d.GetLength()
    # 1 метр = 3.28084 фута
    ONE_METER_FT = 3.28084

    if is_horizontal:
        return [c1]
    else:
        # Для наклонных/вертикальных труб короче 1 метра - только одна отметка в конце
        if pipe_length < ONE_METER_FT:
            return [c1]
        return [c0, c1]


def get_duct_points(duct):
    # Определяем, круглый или прямоугольный воздуховод
    diam_param = duct.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
    diam = 0.0
    if diam_param:
        try:
            diam = diam_param.AsDouble()
        except:
            diam = 0.0

    height_param = duct.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM)
    h = 0.0
    if height_param:
        try:
            h = height_param.AsDouble()
        except:
            h = 0.0

    width_param = duct.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM)
    w = 0.0
    if width_param:
        try:
            w = width_param.AsDouble()
        except:
            w = 0.0

    loc = duct.Location
    if not loc:
        return []

    curve = getattr(loc, 'Curve', None)
    if not curve:
        return []

    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)

    c0 = XYZ(p0.X, p0.Y, p0.Z)
    c1 = XYZ(p1.X, p1.Y, p1.Z)

    is_round = diam > TOL

    if is_round:
        # Круглый воздуховод — отметка по НИЗУ (смещаем на радиус вниз)
        radius = diam / 2.0
        c0_bottom = XYZ(c0.X, c0.Y, c0.Z - radius)
        c1_bottom = XYZ(c1.X, c1.Y, c1.Z - radius)
        
        d = p1 - p0
        is_horizontal = abs(d.Z) < TOL
        if is_horizontal:
            return [c1_bottom]
        else:
            # Для наклонных/вертикальных - проверяем длину (как для труб)
            pipe_length = d.GetLength()
            ONE_METER_FT = 3.28084
            if pipe_length < ONE_METER_FT:
                return [c1_bottom]
            return [c0_bottom, c1_bottom]
    else:
        # Прямоугольный — по НИЗУ
        # Вычисляем направление перпендикулярно оси воздуховода (в горизонтальной плоскости)
        duct_dir = p1 - p0
        duct_dir_horiz = XYZ(duct_dir.X, duct_dir.Y, 0)
        if duct_dir_horiz.GetLength() > TOL:
            duct_dir_horiz = duct_dir_horiz.Normalize()
            # Перпендикуляр в горизонтальной плоскости (поворот на 90 градусов)
            perp = XYZ(-duct_dir_horiz.Y, duct_dir_horiz.X, 0)
        else:
            # Вертикальный воздуховод - берём произвольное направление
            perp = XYZ(1, 0, 0)
        
        # Смещение от центра к краю на половину ширины
        edge_offset = w / 2.0 if w > 0 else 0.0
        
        # Точка: конец воздуховода, низ по Z
        z_bottom = c1.Z - h / 2.0 if h > 0 else c1.Z
        c1_bottom = XYZ(c1.X, c1.Y, z_bottom)
        
        # Возвращаем точку и информацию о смещении (перпендикуляр и полуширина)
        return [(c1_bottom, perp, edge_offset)]


def get_cable_tray_points(cable_tray):
    """Получить точки для кабельного лотка (отметка по низу)."""
    loc = cable_tray.Location
    if not loc:
        return []

    curve = getattr(loc, 'Curve', None)
    if not curve:
        return []

    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)

    # Получаем высоту лотка
    height = 0.0
    try:
        h_param = cable_tray.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM)
        if h_param and h_param.HasValue:
            height = h_param.AsDouble()
    except:
        pass

    # Получаем ширину лотка
    width = 0.0
    try:
        w_param = cable_tray.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM)
        if w_param and w_param.HasValue:
            width = w_param.AsDouble()
    except:
        pass

    # Смещение на низ (height/2)
    z_offset = height / 2.0 if height > 0 else 0.0
    
    c1 = XYZ(p1.X, p1.Y, p1.Z)
    c1_bottom = XYZ(c1.X, c1.Y, c1.Z - z_offset)

    # Вычисляем перпендикуляр для смещения к краю
    tray_dir = p1 - p0
    tray_dir_horiz = XYZ(tray_dir.X, tray_dir.Y, 0)
    if tray_dir_horiz.GetLength() > TOL:
        tray_dir_horiz = tray_dir_horiz.Normalize()
        perp = XYZ(-tray_dir_horiz.Y, tray_dir_horiz.X, 0)
    else:
        perp = XYZ(1, 0, 0)

    edge_offset = width / 2.0 if width > 0 else 0.0

    return [(c1_bottom, perp, edge_offset)]


def get_family_bottom_point(finst):
    # Оборудование/соединительные детали: центр по XY и низ по Z (bounding box на виде)
    bb = None
    
    # Пробуем получить bounding box на активном виде
    try:
        bb = finst.get_BoundingBox(active_view)
    except:
        pass
    
    # Если не удалось - пробуем без вида
    if bb is None or not isinstance(bb, BoundingBoxXYZ):
        try:
            bb = finst.get_BoundingBox(None)
        except:
            pass

    if isinstance(bb, BoundingBoxXYZ) and bb.Min is not None and bb.Max is not None:
        min_pt = bb.Min
        max_pt = bb.Max
        # Центр по XY, низ по Z
        center_xy = XYZ((min_pt.X + max_pt.X) / 2.0,
                        (min_pt.Y + max_pt.Y) / 2.0,
                        min_pt.Z)
        return center_xy
    
    # Резервный вариант - точка вставки
    loc = finst.Location
    if loc is not None:
        try:
            pt = loc.Point
            if pt is not None:
                return pt
        except:
            pass
    
    return None


def get_bottom_face_reference(element, target_z):
    """Получить Reference на нижнюю грань элемента (для FamilyInstance)."""
    try:
        opt = Options()
        opt.ComputeReferences = True
        opt.IncludeNonVisibleObjects = False
        geom = element.get_Geometry(opt)
        if geom is None:
            return None
        
        best_ref = None
        best_dist = float('inf')
        
        for geom_obj in geom:
            solids = []
            if isinstance(geom_obj, Solid):
                solids.append(geom_obj)
            else:
                # GeometryInstance
                try:
                    inst_geom = geom_obj.GetInstanceGeometry()
                    if inst_geom:
                        for g in inst_geom:
                            if isinstance(g, Solid) and g.Volume > 0:
                                solids.append(g)
                except:
                    pass
            
            for solid in solids:
                if solid.Volume < 1e-9:
                    continue
                for face in solid.Faces:
                    try:
                        # Ищем горизонтальную грань близкую к target_z
                        bb = face.GetBoundingBox()
                        uv_mid = (bb.Min + bb.Max) * 0.5
                        normal = face.ComputeNormal(uv_mid)
                        if abs(normal.Z) > 0.9:  # Горизонтальная грань
                            # Берём среднюю Z координату грани
                            pt = face.Evaluate(uv_mid)
                            dist = abs(pt.Z - target_z)
                            if dist < best_dist:
                                best_dist = dist
                                ref = face.Reference
                                if ref is not None:
                                    best_ref = ref
                    except:
                        pass
        
        return best_ref
    except:
        return None


def get_pipe_bottom_reference(pipe, target_point):
    """Получить Reference на нижнюю точку трубы."""
    try:
        opt = Options()
        opt.ComputeReferences = True
        opt.IncludeNonVisibleObjects = False
        geom = pipe.get_Geometry(opt)
        if geom is None:
            return None
        
        best_ref = None
        best_dist = float('inf')
        target_z = target_point.Z
        
        for geom_obj in geom:
            if isinstance(geom_obj, Solid):
                solid = geom_obj
                if solid.Volume < 1e-9:
                    continue
                for face in solid.Faces:
                    try:
                        bb = face.GetBoundingBox()
                        uv_mid = (bb.Min + bb.Max) * 0.5
                        pt = face.Evaluate(uv_mid)
                        # Ищем точку на грани ближайшую к target_point по Z
                        dist = abs(pt.Z - target_z)
                        if dist < best_dist:
                            best_dist = dist
                            ref = face.Reference
                            if ref is not None:
                                best_ref = ref
                    except:
                        pass
        
        return best_ref
    except:
        return None


def project_point_to_view_plane(point, view):
    # Для SpotElevation достаточно использовать мировые координаты
    return point

def choose_side_by_neighbors(view, origin, element_id, neighbors, offset_ft):
    """Определяем, куда ставить выноску (влево/вправо) по соседним элементам."""
    try:
        right = view.RightDirection
        up = view.UpDirection
    except:
        right = XYZ(1, 0, 0)
        up = XYZ(0, 1, 0)

    if right.GetLength() < TOL:
        right = XYZ(1, 0, 0)
    if up.GetLength() < TOL:
        up = XYZ(0, 1, 0)

    right = right.Normalize()
    up = up.Normalize()

    # Радиус поиска соседей — несколько длин выноски
    search_half = offset_ft * 4.0

    left_count = 0
    right_count = 0

    for nid, cpt in neighbors:
        if nid == element_id:
            continue
        v = cpt - origin
        dx = v.DotProduct(right)
        dy = v.DotProduct(up)

        if abs(dx) > search_half or abs(dy) > search_half:
            continue

        if dx > 0:
            right_count += 1
        elif dx < 0:
            left_count += 1

    # Сторона с меньшим количеством соседей
    if left_count < right_count:
        side_sign = -1.0  # влево
    elif right_count < left_count:
        side_sign = 1.0   # вправо
    else:
        side_sign = 1.0   # по умолчанию вправо

    return right, side_sign


def get_leader_points(view, origin, element_id, neighbors, extra_offset_vec=None):
    # Горизонтальная выноска длиной ~10 мм на листе.
    # extra_offset_vec - дополнительное смещение (напр. от края воздуховода)
    try:
        scale = view.Scale
    except:
        scale = 100

    offset_m = (PAPER_LEADER_MM / 1000.0) * float(scale)
    offset_ft = offset_m / 0.3048

    right, side_sign = choose_side_by_neighbors(view, origin, element_id, neighbors, offset_ft)
    right_norm = right.Normalize()
    
    # Базовое смещение выноски (всегда горизонтально на виде)
    offset_vec = right_norm.Multiply(offset_ft * side_sign)
    
    # Добавляем дополнительное смещение (от края элемента) в ту же сторону
    # Проецируем extra_offset_vec на горизонтальное направление вида
    if extra_offset_vec is not None:
        # Проекция на горизонталь вида (right_norm)
        proj_len = extra_offset_vec.DotProduct(right_norm)
        if abs(proj_len) > TOL:
            # Берём только горизонтальную составляющую смещения
            extra_horiz = right_norm.Multiply(abs(proj_len) * side_sign)
            offset_vec = offset_vec + extra_horiz

    bend = origin + offset_vec
    
    # end - конечная точка выноски (где текст)
    # Смещаем дальше в ту же сторону, чтобы текст был ориентирован правильно
    text_offset = right_norm.Multiply(offset_ft * 0.5 * side_sign)  # Небольшое смещение для ориентации текста
    end = bend + text_offset
    
    return bend, end, side_sign


def create_spot_elevation(view, spot_type, element, point, neighbors, failed_elements=None, extra_offset_info=None, use_bottom_ref=False):
    # Reference всегда к элементу; если Revit не умеет ставить высотную отметку для
    # этой категории на данном виде, NewSpotElevation бросит исключение, и мы вернём None.
    # extra_offset_info = (perp_direction, offset_distance) - доп. смещение для прямоугольных воздуховодов
    # use_bottom_ref = True - ищем Reference на нижнюю грань
    
    reference = None
    
    # Для труб пробуем получить Reference на нижнюю грань
    if use_bottom_ref and isinstance(element, Pipe):
        reference = get_pipe_bottom_reference(element, point)
    
    # Для воздуховодов пробуем получить Reference на нижнюю грань
    if use_bottom_ref and reference is None and isinstance(element, Duct):
        reference = get_pipe_bottom_reference(element, point)  # Тот же метод работает для воздуховодов
    
    # Для FamilyInstance пробуем получить Reference из геометрии (нижняя грань)
    if reference is None and isinstance(element, FamilyInstance):
        reference = get_bottom_face_reference(element, point.Z)
    
    # Если не получили из геометрии - пробуем стандартный способ
    if reference is None:
        try:
            reference = Reference(element)
        except Exception as e:
            if failed_elements is not None:
                failed_elements.append((element, u"Не удалось создать Reference: {}".format(str(e))))
            return None

    base_origin = project_point_to_view_plane(point, view)
    
    # Для прямоугольных воздуховодов: смещаем origin к краю
    # origin - точка на элементе (край воздуховода)
    # bend/end - точка где текст марки
    origin = base_origin
    if extra_offset_info is not None:
        perp, offset_dist = extra_offset_info
        if offset_dist > 0:
            # Сначала определяем сторону выноски
            bend_test, end_test, side_sign = get_leader_points(view, base_origin, element.Id, neighbors, None)
            
            # Смещаем origin к краю в сторону выноски
            dot = perp.DotProduct(view.RightDirection)
            if dot * side_sign < 0:
                perp = perp.Multiply(-1)
            origin = XYZ(base_origin.X + perp.X * offset_dist,
                         base_origin.Y + perp.Y * offset_dist,
                         base_origin.Z)
    
    bend, end, side_sign = get_leader_points(view, origin, element.Id, neighbors, None)
    ref_pt = base_origin  # ref_pt - точка отсчёта высоты (центр воздуховода по низу)

    spot = None
    try:
        spot = doc.Create.NewSpotElevation(
            view,
            reference,
            origin,
            bend,
            end,
            ref_pt,
            True  # hasLeader
        )
    except Exception as e1:
        # fallback: без выноски
        try:
            spot = doc.Create.NewSpotElevation(
                view,
                reference,
                origin,
                origin,
                origin,
                origin,
                False
            )
        except Exception as e2:
            if failed_elements is not None:
                cat_name = u"?"
                try:
                    cat_name = element.Category.Name
                except:
                    pass
                failed_elements.append((element, u"Категория: {}, Ошибка: {}".format(cat_name, str(e2))))
            return None

    try:
        spot.ChangeTypeId(spot_type.Id)
    except:
        pass

    elev_ft = point.Z
    elev_m = elev_ft * 0.3048
    text_value = u"{0:+0.3f}".format(elev_m)

    try:
        param = spot.get_Parameter(BuiltInParameter.SPOT_ELEV_TEXT)
        if param and not param.IsReadOnly:
            param.Set(text_value)
        else:
            p2 = spot.get_Parameter(BuiltInParameter.DIM_TEXT)
            if p2 and not p2.IsReadOnly:
                p2.Set(text_value)
    except:
        pass

    return spot


def main():
    if active_view is None:
        forms.alert(u"Нет активного вида.", exitscript=True)
        return

    elements = get_selected_elements()
    if not elements:
        forms.alert(u"Не выбрано ни одного подходящего элемента.", exitscript=True)
        return

    spot_type = get_spot_type_fixed()
    if spot_type is None:
        return

    has_pipes = any(isinstance(el, Pipe) for el in elements)
    mode = "axis"
    if has_pipes:
        m = ask_axis_or_bottom_for_pipes()
        if m is None:
            return
        mode = m

    # Список соседей для всех элементов на виде
    neighbors = build_neighbor_points()

    created_count = 0
    created_ids = []
    failed_elements = []
    skipped_no_point = 0

    with revit.Transaction(u"Высотные отметки Spot Elevation"):
        for el in elements:
            pts_data = []  # Список кортежей (point, extra_offset_info, use_bottom_ref)
            use_bottom = (mode == 'bottom')  # Для труб в режиме "низ"

            if isinstance(el, Pipe):
                # Для труб - просто точки без доп. смещения
                pipe_pts = get_pipe_points(el, mode)
                pts_data = [(pt, None, use_bottom) for pt in pipe_pts]
            elif isinstance(el, Duct):
                # Для воздуховодов - может возвращать кортежи (point, perp, offset) или просто точки
                # Всегда ставим отметку по низу, поэтому use_bottom_ref=True
                duct_result = get_duct_points(el)
                for item in duct_result:
                    if isinstance(item, tuple) and len(item) == 3:
                        # Прямоугольный воздуховод: (point, perp, offset)
                        pt, perp, offset = item
                        pts_data.append((pt, (perp, offset), True))
                    else:
                        # Круглый воздуховод: просто точка (уже смещена на низ)
                        pts_data.append((item, None, True))
            elif isinstance(el, CableTray):
                # Для кабельных лотков - отметка по низу
                tray_result = get_cable_tray_points(el)
                for item in tray_result:
                    if isinstance(item, tuple) and len(item) == 3:
                        pt, perp, offset = item
                        pts_data.append((pt, (perp, offset), True))
                    else:
                        pts_data.append((item, None, True))

            for pt_info in pts_data:
                if pt_info is None:
                    continue
                pt, extra_offset, use_bottom_ref = pt_info
                if pt is None:
                    continue
                spot = create_spot_elevation(active_view, spot_type, el, pt, neighbors, failed_elements, extra_offset, use_bottom_ref)
                if spot:
                    created_count += 1
                    created_ids.append(spot.Id)

    # Выделяем созданные отметки, чтобы было проще их найти
    if created_ids:
        id_list = List[ElementId]()
        for sid in created_ids:
            id_list.Add(sid)
        uidoc.Selection.SetElementIds(id_list)

    # Формируем сообщение
    msg = u"Создано высотных отметок: {0}".format(created_count)
    if skipped_no_point > 0:
        msg += u"\nПропущено (не удалось определить точку): {0}".format(skipped_no_point)
    if failed_elements:
        msg += u"\nНе удалось создать отметку для {0} элементов:".format(len(failed_elements))
        # Показываем первые 3 ошибки
        for i, (el, reason) in enumerate(failed_elements[:3]):
            try:
                el_id = el.Id.IntegerValue
            except:
                el_id = "?"
            msg += u"\n  - ID {}: {}".format(el_id, reason)
        if len(failed_elements) > 3:
            msg += u"\n  ... и ещё {}".format(len(failed_elements) - 3)
    
    forms.alert(msg)


if __name__ == '__main__':
    main()
